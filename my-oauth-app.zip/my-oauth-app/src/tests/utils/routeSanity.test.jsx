import { BrowserRouter } from 'react-router-dom';

test('BrowserRouter is defined', () => {
  expect(BrowserRouter).toBeDefined();
});
import { BrowserRouter } from 'react-router-dom';

test('BrowserRouter should be defined', () => {
  expect(BrowserRouter).toBeDefined();
});
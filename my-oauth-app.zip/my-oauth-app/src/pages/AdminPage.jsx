const AdminPage = () => (
  <div>
    <h2>Admin Panel</h2>
    <p>Only users with the 'admin' role can access this page.</p>
  </div>
);

export default AdminPage;
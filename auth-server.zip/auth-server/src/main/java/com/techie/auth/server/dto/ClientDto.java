package com.techie.auth.server.dto;


import lombok.Data;

@Data
public class ClientDto {
    // Getters and setters
    private String clientId;
    private String redirectUri;

  }
